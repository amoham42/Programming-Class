import random

# Option    > rock, paper, scissors
# Rock = 0  
# Paper = 1
# Scissors = 2
# random.randint()
user = int(input("0 > Rock | 1 > Paper | 2 > Scissors: "))
computer = random.randint(0, 2)

def game(user):
    if user == 0:   # Rock
        if computer == 0:
            print(" Tied") # مساوی
            print("Computer Choose Rock")
        elif computer == 1:
            print(" Lost")
            print("Computer Choose Paper")
        else:
            print(" Win")
            print("Computer Choose Scissors")
    elif user == 1: # Paper
        if computer == 0:
            print(" Win") # مساوی
            print("Computer Choose Rock")
        elif computer == 1:
            print(" Tied")
            print("Computer Choose Paper")
        else:
            print(" Loss")
            print("Computer Choose Scissors")
    else:   # Scissors
        if computer == 0:
            print(" Lost") # مساوی
            print("Computer Choose Rock")
        elif computer == 1:
            print(" Win")
            print("Computer Choose Paper")
        else:
            print(" Tied")
            print("Computer Choose Scissors")

game(user)