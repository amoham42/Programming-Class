import turtle
import random

# Set up the screen
wn = turtle.Screen()
wn.title("Programming Class")
wn.bgcolor("white")
wn.setup(width=600, height=600)

# Define a list of colors for the turtle to change to
colors = ["blue", "purple", "orange", "pink", "yellow", "brown", "cyan"]

# Create the player turtle
player = turtle.Turtle()
player.shape("turtle")
player.color(random.choice(colors))
player.pensize(4)  # Set the size of the pen
player.penup()
player.speed(0)

# TODO: Make the player go to a random position from -280 to 280 in both x and y plane
#       change the function below to take two integers for x and y plane and give random number to them.
#___________________________________________
player.goto(random.randint(-280, 280), random.randint(-280, 280))
#player.goto(x, y)
#___________________________________________
player.setheading(random.choice([45, 135, 225, 315]))  # Set initial diagonal direction
player.pendown()  # Start drawing

# TODO: Make a list and add different shapes like circle, triangle, and square
# and use them when making shapes for collisions and eating.
shapes = ["circle", "triangle", "square"]

# Create red cubes
num_red_cubes = 10
red_cubes = []

for _ in range(num_red_cubes):
    cube = turtle.Turtle()
    # TODO: use the different random shapes here.
    cube.shape(random.choice(shapes))
    cube.color("red")
    cube.penup()
    cube.speed(0)
    x = random.randint(-280, 280)
    y = random.randint(-280, 280)
    cube.goto(x, y)
    red_cubes.append(cube)

# Create green cubes
num_green_cubes = 5
green_cubes = []

for _ in range(num_green_cubes):
    cube = turtle.Turtle()
    cube.shapesize(1.5, 1.5)
    cube.shape("square")
    cube.color("green")
    cube.penup()
    cube.speed(0)
    x = random.randint(-280, 280)
    y = random.randint(-280, 280)
    cube.goto(x, y)
    green_cubes.append(cube)

# Collision avoidance counter
collision_avoidance = 0

# Function to adjust heading after border collision
def adjust_heading(adjust):
    new_heading = (player.heading() + 180) % 360
    # TODO make a integer and take out the (-10) degrees out of this function
    # make the function take an integer.
    player.color(random.choice(colors))

    player.setheading(new_heading + adjust)

def changeDirection():
    global collision_avoidance
    new_heading = random.choice([45, 135, 225, 315])
    player.setheading(new_heading)
    collision_avoidance = 4
    player.color(random.choice(colors))


def deleteCube(cube):
    cube.hideturtle()
    green_cubes.remove(cube)
    player.color("green")  # Change back to green after eating a green cube


# Function to move the turtle
def move_turtle():
    global collision_avoidance

    player.forward(15)
    x, y = player.position()


    # TODO: fill the if else statements below and make the turtle eat the green 
    # cubes and change direction when it hits the walls or it hits the red cubes.
    if collision_avoidance > 0:
        # Skip collision check
        collision_avoidance -= 1
    else:
        # Check for collision with window border and change direction
        if x > 280 or x < -280 or y > 280 or y < -280:
            collision_avoidance = 8
            adjust_heading(-10)

        # Check for near collision with red cubes and change direction
        for cube in red_cubes:
            if player.distance(cube) < 30:
                collision_avoidance = 8
                adjust_heading(-30)


        # Check for collision with green cubes and "eat" them
        for cube in green_cubes:
            if player.distance(cube) < 20:
                deleteCube(cube)

# Main game loop
def game_loop():
    move_turtle()
    wn.ontimer(game_loop, 1)

# Start the game loop
game_loop()

wn.mainloop()
