import random

# for loops
# while loops


# for player in range(0, 10):
#     print(random.randint(0, 10))


fruits = ['banana', 'apple', 'cherry']

# for i in range(0, 10):
#     for j in range(5, 12):
#         print(j)

for i in fruits:
    i += i

    print(i)

count = 5
while count > 0:
    if count == 3:
        break
    print(count)
    count -= 1




