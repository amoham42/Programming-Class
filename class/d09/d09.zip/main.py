from game import Game



game = Game()
game.render()