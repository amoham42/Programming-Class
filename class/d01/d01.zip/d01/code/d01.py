str = input("type a number: ")
second_number = input("type second number: ")

print(int(str) + int(second_number))

# "52"