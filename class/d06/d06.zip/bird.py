class Bird:
    def __init__(self, color, position):
        self.radius = 20
        self.color = color
        self.speed = 5
        self.power = 0
        self.position = position
