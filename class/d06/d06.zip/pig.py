class Pig:
    def __init__(self, position):
        self.radius = 20
        self.color = (0, 255, 0)
        self.size = 50
        self.position = position
